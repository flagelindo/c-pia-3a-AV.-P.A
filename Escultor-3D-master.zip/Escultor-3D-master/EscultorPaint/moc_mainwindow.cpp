/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[41];
    char stringdata0[783];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 17), // "end_create_sculpt"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 8), // "finished"
QT_MOC_LITERAL(4, 39, 10), // "update_dim"
QT_MOC_LITERAL(5, 50, 2), // "nx"
QT_MOC_LITERAL(6, 53, 2), // "ny"
QT_MOC_LITERAL(7, 56, 2), // "nz"
QT_MOC_LITERAL(8, 59, 16), // "update_positions"
QT_MOC_LITERAL(9, 76, 1), // "x"
QT_MOC_LITERAL(10, 78, 1), // "y"
QT_MOC_LITERAL(11, 80, 1), // "z"
QT_MOC_LITERAL(12, 82, 3), // "row"
QT_MOC_LITERAL(13, 86, 3), // "col"
QT_MOC_LITERAL(14, 90, 13), // "sculptUpdated"
QT_MOC_LITERAL(15, 104, 25), // "on_pushButton_11_released"
QT_MOC_LITERAL(16, 130, 25), // "on_pushButton_13_released"
QT_MOC_LITERAL(17, 156, 25), // "on_pushButton_12_released"
QT_MOC_LITERAL(18, 182, 24), // "on_pushButton_3_released"
QT_MOC_LITERAL(19, 207, 24), // "on_pushButton_4_released"
QT_MOC_LITERAL(20, 232, 24), // "on_pushButton_5_released"
QT_MOC_LITERAL(21, 257, 24), // "on_pushButton_6_released"
QT_MOC_LITERAL(22, 282, 24), // "on_pushButton_7_released"
QT_MOC_LITERAL(23, 307, 24), // "on_pushButton_8_released"
QT_MOC_LITERAL(24, 332, 24), // "on_pushButton_9_released"
QT_MOC_LITERAL(25, 357, 25), // "on_pushButton_10_released"
QT_MOC_LITERAL(26, 383, 26), // "on_spinBox_13_valueChanged"
QT_MOC_LITERAL(27, 410, 4), // "arg1"
QT_MOC_LITERAL(28, 415, 35), // "on_horizontalSlider_13_valueC..."
QT_MOC_LITERAL(29, 451, 5), // "value"
QT_MOC_LITERAL(30, 457, 26), // "on_spinBox_12_valueChanged"
QT_MOC_LITERAL(31, 484, 35), // "on_horizontalSlider_12_valueC..."
QT_MOC_LITERAL(32, 520, 26), // "on_spinBox_11_valueChanged"
QT_MOC_LITERAL(33, 547, 35), // "on_horizontalSlider_11_valueC..."
QT_MOC_LITERAL(34, 583, 29), // "on_doubleSpinBox_valueChanged"
QT_MOC_LITERAL(35, 613, 31), // "on_doubleSpinBox_2_valueChanged"
QT_MOC_LITERAL(36, 645, 31), // "on_doubleSpinBox_3_valueChanged"
QT_MOC_LITERAL(37, 677, 31), // "on_doubleSpinBox_4_valueChanged"
QT_MOC_LITERAL(38, 709, 24), // "on_pushButton_15_pressed"
QT_MOC_LITERAL(39, 734, 22), // "on_pushButton_released"
QT_MOC_LITERAL(40, 757, 25) // "on_pushButton_14_released"

    },
    "MainWindow\0end_create_sculpt\0\0finished\0"
    "update_dim\0nx\0ny\0nz\0update_positions\0"
    "x\0y\0z\0row\0col\0sculptUpdated\0"
    "on_pushButton_11_released\0"
    "on_pushButton_13_released\0"
    "on_pushButton_12_released\0"
    "on_pushButton_3_released\0"
    "on_pushButton_4_released\0"
    "on_pushButton_5_released\0"
    "on_pushButton_6_released\0"
    "on_pushButton_7_released\0"
    "on_pushButton_8_released\0"
    "on_pushButton_9_released\0"
    "on_pushButton_10_released\0"
    "on_spinBox_13_valueChanged\0arg1\0"
    "on_horizontalSlider_13_valueChanged\0"
    "value\0on_spinBox_12_valueChanged\0"
    "on_horizontalSlider_12_valueChanged\0"
    "on_spinBox_11_valueChanged\0"
    "on_horizontalSlider_11_valueChanged\0"
    "on_doubleSpinBox_valueChanged\0"
    "on_doubleSpinBox_2_valueChanged\0"
    "on_doubleSpinBox_3_valueChanged\0"
    "on_doubleSpinBox_4_valueChanged\0"
    "on_pushButton_15_pressed\0"
    "on_pushButton_released\0on_pushButton_14_released"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  149,    2, 0x08 /* Private */,
       4,    3,  152,    2, 0x08 /* Private */,
       8,    6,  159,    2, 0x08 /* Private */,
      15,    0,  172,    2, 0x08 /* Private */,
      16,    0,  173,    2, 0x08 /* Private */,
      17,    0,  174,    2, 0x08 /* Private */,
      18,    0,  175,    2, 0x08 /* Private */,
      19,    0,  176,    2, 0x08 /* Private */,
      20,    0,  177,    2, 0x08 /* Private */,
      21,    0,  178,    2, 0x08 /* Private */,
      22,    0,  179,    2, 0x08 /* Private */,
      23,    0,  180,    2, 0x08 /* Private */,
      24,    0,  181,    2, 0x08 /* Private */,
      25,    0,  182,    2, 0x08 /* Private */,
      26,    1,  183,    2, 0x08 /* Private */,
      28,    1,  186,    2, 0x08 /* Private */,
      30,    1,  189,    2, 0x08 /* Private */,
      31,    1,  192,    2, 0x08 /* Private */,
      32,    1,  195,    2, 0x08 /* Private */,
      33,    1,  198,    2, 0x08 /* Private */,
      34,    1,  201,    2, 0x08 /* Private */,
      35,    1,  204,    2, 0x08 /* Private */,
      36,    1,  207,    2, 0x08 /* Private */,
      37,    1,  210,    2, 0x08 /* Private */,
      38,    0,  213,    2, 0x08 /* Private */,
      39,    0,  214,    2, 0x08 /* Private */,
      40,    0,  215,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,    5,    6,    7,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Bool,    9,   10,   11,   12,   13,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   27,
    QMetaType::Void, QMetaType::Int,   29,
    QMetaType::Void, QMetaType::Int,   27,
    QMetaType::Void, QMetaType::Int,   29,
    QMetaType::Void, QMetaType::Int,   27,
    QMetaType::Void, QMetaType::Int,   29,
    QMetaType::Void, QMetaType::Double,   27,
    QMetaType::Void, QMetaType::Double,   27,
    QMetaType::Void, QMetaType::Double,   27,
    QMetaType::Void, QMetaType::Double,   27,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->end_create_sculpt((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->update_dim((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 2: _t->update_positions((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6]))); break;
        case 3: _t->on_pushButton_11_released(); break;
        case 4: _t->on_pushButton_13_released(); break;
        case 5: _t->on_pushButton_12_released(); break;
        case 6: _t->on_pushButton_3_released(); break;
        case 7: _t->on_pushButton_4_released(); break;
        case 8: _t->on_pushButton_5_released(); break;
        case 9: _t->on_pushButton_6_released(); break;
        case 10: _t->on_pushButton_7_released(); break;
        case 11: _t->on_pushButton_8_released(); break;
        case 12: _t->on_pushButton_9_released(); break;
        case 13: _t->on_pushButton_10_released(); break;
        case 14: _t->on_spinBox_13_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_horizontalSlider_13_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_spinBox_12_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_horizontalSlider_12_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_spinBox_11_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->on_horizontalSlider_11_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_doubleSpinBox_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 21: _t->on_doubleSpinBox_2_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 22: _t->on_doubleSpinBox_3_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 23: _t->on_doubleSpinBox_4_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 24: _t->on_pushButton_15_pressed(); break;
        case 25: _t->on_pushButton_released(); break;
        case 26: _t->on_pushButton_14_released(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 27;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
