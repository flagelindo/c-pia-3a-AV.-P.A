#include "figurageometrica.h"

FiguraGeometrica::FiguraGeometrica()
{
}

FiguraGeometrica::~FiguraGeometrica()
{

}

void FiguraGeometrica::draw(Sculptor &t){


}
